Random Access File Reader


